class CacheKeys {
  static const String tokenKey = "CARER_STAFF_TOKEN";
}
