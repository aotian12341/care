class AppConfig {
  static String baseUrl = "https://175.24.100.139:8050/api";

  static String image =
      "https://pica.zhimg.com/v2-77be8f3b85a2bf587c3d2cff1c9a297f_1440w.jpg?source=172ae18b";

  static const String androidKey = "5c9026af07d51442598dbcad55629ce1";
  static const String iosKey = "a9921da394a5dafee29675adc0cedb61";
  static const String webKey =
      "b41d169b416189af9aafb070c1397196"; //"df73ec06b144c1197868fbea72ba6272";
}
