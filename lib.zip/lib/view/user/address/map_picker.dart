import 'package:amap_flutter_base/amap_flutter_base.dart';
import 'package:amap_flutter_map/amap_flutter_map.dart';
import 'package:care/common/location_manager.dart';
import 'package:care/widget/loader.dart';
import 'package:care/widget/page_widget.dart';
import 'package:city_pickers/city_pickers.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/colors.dart';
import '../../../constants/app_config.dart';
import 'package:care/widget/view_ex.dart';

import '../../../controller/address_controller.dart';
import 'pois_info.dart';

/// 地图选点
class MapPicker extends StatefulWidget {
  const MapPicker({Key? key}) : super(key: key);

  @override
  State<MapPicker> createState() => _MapPickerState();
}

class _MapPickerState extends State<MapPicker> {
  static const AMapApiKey amapApiKeys =
      AMapApiKey(androidKey: AppConfig.androidKey, iosKey: AppConfig.iosKey);
  static const AMapPrivacyStatement amapPrivacyStatement =
      AMapPrivacyStatement(hasContains: true, hasShow: true, hasAgree: true);

  /// 地图控制器
  AMapController? _mapController;

  final locCity = "请选择".obs;
  final keyWord = TextEditingController();

  final loaderController = LoaderController();

  final dataList = <PoisPois>[].obs;

  Function(Map<String, dynamic> value)? locationCallBack;

  int page = 1;

  /// 经纬度
  final lat = 0.0.obs, lng = 0.0.obs;

  Widget? aMap;
  Widget? listView;

  Future<void> refresh() async {
    loaderController.loading();
    getData(isRefresh: true);
  }

  void getData({bool isRefresh = false}) {
    if (isRefresh) {
      page = 1;
    } else {
      page++;
    }

    if (keyWord.text.isNotEmpty) {
      AddressController().getLocationByKeyword(
          keyWord: keyWord.text,
          city: locCity.value,
          success: (PoisInfo value) {
            if (page == 1) {
              dataList.clear();
            }
            dataList.addAll(value.pois ?? []);

            loaderController.loadFinish(data: dataList, noMore: false);
          },
          fail: (error) {});
    } else {
      AddressController().getLocationByGps(
          lat: lat.value,
          lng: lng.value,
          success: (value) {
            if (page == 1) {
              dataList.clear();
            }
            dataList.addAll(value.pois ?? []);

            loaderController.loadFinish(data: dataList, noMore: false);
          },
          fail: (error) {});
    }
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      getLocation();
    });
  }

  void getLocation() {
    LocationManager().getLocation(
        isOnce: true,
        showLoading: true,
        success: locationCallBack = (value) {
          if (value["city"] != null) {
            try {
              locCity(value["city"].toString());
              lat(double.parse(value["latitude"].toString()));
              lng(double.parse(value["longitude"].toString()));
              if (_mapController != null) {
                _mapController!.moveCamera(
                    CameraUpdate.newLatLng(LatLng(lat.value, lng.value)));
              }
              Future.delayed(const Duration(seconds: 1), () {
                getData(isRefresh: true);
              });
            } catch (e) {
              print(e);
            }
          }
        });
  }

  @override
  Widget build(BuildContext context) {
    return PageWidget(
        isCustom: "short",
        titleLabel: "添加地址",
        body: Column(
          children: [
            getSearch(),
            12.v,
            getMap(),
            getDataView().expanded(),
          ],
        ));
  }

  Widget getSearch() {
    return Obx(() {
      return Row(
        children: [
          Row(
            children: [
              locCity.value.t.s(16).c(DSColors.title),
              2.h,
              Icon(
                Icons.arrow_drop_down,
                size: 15,
                color: DSColors.title,
              )
            ],
          ).size(width: 100).onTap(() async {
            final temp = await CityPickers.showCityPicker(
                context: context, showType: ShowType.pc);
            if (temp != null) {
              locCity(temp.cityName ?? "");
            }
          }),
          12.h,
          TextField(
            controller: keyWord,
            onChanged: (value) {
              Future.delayed(const Duration(seconds: 1), () {
                if (value == keyWord.text) {
                  refresh();
                }
              });
            },
            decoration: const InputDecoration(
                border: InputBorder.none, hintText: "请输入关键字"),
          )
              .padding(padding: const EdgeInsets.symmetric(horizontal: 10))
              .border(color: DSColors.describe)
              .borderRadius(radius: 4)
              .expanded()
        ],
      ).padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8));
    });
  }

  /// 地图创建回调
  void onMapCreated(AMapController controller) {
    _mapController = controller;
    if (lat.value > 0 && lng.value > 0) {
      // isMove = true;
      _mapController!.moveCamera(
          CameraUpdate.newLatLngZoom(LatLng(lat.value, lng.value), 18));
    }
  }

  Widget getMap() {
    return Obx(() {
      final set = <Marker>{};
      if (lat.value > 0 && lng.value > 0) {
        set.add(Marker(position: LatLng(lat.value, lng.value)));
      }
      return AMapWidget(
        initialCameraPosition:
            CameraPosition(target: LatLng(lat.value, lng.value), zoom: 18),
        apiKey: amapApiKeys,
        onMapCreated: onMapCreated,
        privacyStatement: amapPrivacyStatement,
        markers: set,
        onCameraMoveEnd: (CameraPosition loc) {
          lat(loc.target.latitude);
          lng(loc.target.longitude);
          refresh();
        },
      )
          .size(height: 200)
          .margin(margin: const EdgeInsets.symmetric(horizontal: 12));
    });
  }

  Widget getDataView() {
    listView ??= Obx(() {
      return Loader(
          onRefresh: refresh,
          onLoad: getData,
          controller: loaderController,
          child: ListView.builder(
            itemCount: dataList.length,
            itemBuilder: (BuildContext context, int index) {
              final item = dataList[index];
              return Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      (item.name ?? "").t.s(16).c(DSColors.title),
                      4.v,
                      Row(
                        children: [
                          (item.address ?? "")
                              .t
                              .s(14)
                              .c(DSColors.subTitle)
                              .flexible()
                        ],
                      )
                    ],
                  ).expanded(),
                  Icon(
                    Icons.chevron_right,
                    size: 20,
                    color: DSColors.describe,
                  ),
                ],
              )
                  .borderOnly(bottom: BorderSide(color: DSColors.divider))
                  .margin(margin: const EdgeInsets.only(bottom: 12))
                  .padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8))
                  .onTap(() {
                Navigator.pop(context, item);
              });
            },
          ));
    });
    return listView!;
  }

  @override
  void dispose() {
    super.dispose();

    LocationManager().removeListener((loc) => locationCallBack);
  }
}
