import 'package:care/generated/json/base/json_convert_content.dart';
import 'package:care/model/shop_Info.dart';

ShopInfo $ShopInfoFromJson(Map<String, dynamic> json) {
  final ShopInfo shopInfo = ShopInfo();
  return shopInfo;
}

Map<String, dynamic> $ShopInfoToJson(ShopInfo entity) {
  final Map<String, dynamic> data = <String, dynamic>{};
  return data;
}
