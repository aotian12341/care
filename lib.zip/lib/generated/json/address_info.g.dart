import 'package:care/generated/json/base/json_convert_content.dart';
import 'package:care/model/address_info.dart';

AddressInfo $AddressInfoFromJson(Map<String, dynamic> json) {
  final AddressInfo addressInfo = AddressInfo();
  final int? id = jsonConvert.convert<int>(json['id']);
  if (id != null) {
    addressInfo.id = id;
  }
  final String? addressName = jsonConvert.convert<String>(json['addressName']);
  if (addressName != null) {
    addressInfo.addressName = addressName;
  }
  final String? addressNo = jsonConvert.convert<String>(json['addressNo']);
  if (addressNo != null) {
    addressInfo.addressNo = addressNo;
  }
  final String? userNo = jsonConvert.convert<String>(json['userNo']);
  if (userNo != null) {
    addressInfo.userNo = userNo;
  }
  final String? contacts = jsonConvert.convert<String>(json['contacts']);
  if (contacts != null) {
    addressInfo.contacts = contacts;
  }
  final String? telephone = jsonConvert.convert<String>(json['telephone']);
  if (telephone != null) {
    addressInfo.telephone = telephone;
  }
  final String? province = jsonConvert.convert<String>(json['province']);
  if (province != null) {
    addressInfo.province = province;
  }
  final String? city = jsonConvert.convert<String>(json['city']);
  if (city != null) {
    addressInfo.city = city;
  }
  final String? district = jsonConvert.convert<String>(json['district']);
  if (district != null) {
    addressInfo.district = district;
  }
  final String? address = jsonConvert.convert<String>(json['address']);
  if (address != null) {
    addressInfo.address = address;
  }
  final String? is_defalut = jsonConvert.convert<String>(json['is_defalut']);
  if (is_defalut != null) {
    addressInfo.is_defalut = is_defalut;
  }
  return addressInfo;
}

Map<String, dynamic> $AddressInfoToJson(AddressInfo entity) {
  final Map<String, dynamic> data = <String, dynamic>{};
  data['id'] = entity.id;
  data['addressName'] = entity.addressName;
  data['addressNo'] = entity.addressNo;
  data['userNo'] = entity.userNo;
  data['contacts'] = entity.contacts;
  data['telephone'] = entity.telephone;
  data['province'] = entity.province;
  data['city'] = entity.city;
  data['district'] = entity.district;
  data['address'] = entity.address;
  data['is_defalut'] = entity.is_defalut;
  return data;
}
