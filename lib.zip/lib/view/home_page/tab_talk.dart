import 'package:flutter/material.dart';

class TabTalk extends StatefulWidget {
  const TabTalk({Key? key}) : super(key: key);

  @override
  _TabTalkState createState() => _TabTalkState();
}

class _TabTalkState extends State<TabTalk> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
